                <div id="header">

                                <form action="mng-search.php">
                                <input name="username" value="<?php echo $l['menu']['Search']; ?>" />
                                </form>

                                <h1><a href="index.php"> <img src="images/daloradius_small.png" border=0/></a></h1>

                                <h2>
                                
                                <? echo $l['all']['copyright1']; ?>
                                
				                                </h2>

                                <ul id="nav">
				<a name='top'></a>

				<li><a href="index.php" >主页</a></li>
				<li><a href="mng-main.php" >管理</a></li>
				<li><a href="rep-main.php" >报告</a></li>
				<li><a href="acct-main.php" >账单</a></li>
				<li><a href="bill-main.php" >记账</a></li>
				<li><a href="config-main.php" >配置</a></li>
				<li><a href="Clean-expired-data.php" >清理过期用户</a></li>
				<li><a href="Clean-data-cache.php" >清理数据缓存</a></li>
                                </ul>

