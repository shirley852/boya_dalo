<?php
// require("system.php");
// /* 获取远程服务器的公告 */
// $opts = array(
	// 'http'=>array(
		// 'method'=>"GET",
		// 'timeout'=>10
	// )
// );
// $do = $_POST["do"];
// $cache=R."/cache/access.tmp";

// if($do == "getMsg" ){
	// if(is_file($cache) && time()-filemtime ($cache)<3*60){ //缓存机制 避免每次都查询官网 造成负荷过大 缓存3分钟
		// $json = file_get_contents($cache);
	// }else{
		// $context = stream_context_create($opts);
		// $json = file_get_contents('http://api.dingd.cn/getGG.php?do=getMsg', false, $context);
		// file_put_contents($cache,$json);
	// }
	// if($json){
		// die($json);
	// }
	// die(json_encode(["status"=>"error"]));
// }else{
	// $context = stream_context_create($opts);
	// $json = file_get_contents('http://api.dingd.cn/getGG.php?do=readMsg&id='.$_POST["id"], false, $context);
	// @unlink($cache);
	// die(json_encode(["status"=>"error"]));
// }