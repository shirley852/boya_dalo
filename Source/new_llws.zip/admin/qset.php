<div class=" center-block" style="float: none;">
<?php
$user = trim($_GET['user']);
if(!$user || !$row = db('radcheck')->where(array('username'=>$user))->find()){ exit("账号不存在!");}
$row_1 = db('radusergroup')->where(array('username'=>$user))->find();
if($_POST['type']=="update"){
$pass = trim($_POST['pass']);
$state = trim($_POST['state']);
$enddate = trim($_POST['enddate']);
	if(db('radcheck')->where(array('username'=>$user))->update(array(
			'username'=>$user,
			'attribute'=>$state,
			'op'=>':=',
			'value'=>$pass
			))){
				db('radusergroup')->where(array('username'=>$user))->update(array(
			'username'=>$user,
			'GroupName'=>$enddate,
			'priority'=>0
			));
		tip_success("修改成功",'user_list.php?a=qset&user='.$user);
	}else{
		tip_failed('修改失败！','user_list.php?a=qset&user='.$user);
	}
}else{
?>

<style>
.main
{
	
	height: 400px;
	
	margin:10px;
	margin-top: 20px;
	overflow: hidden;
}

#line
{
	width: 100%;
	height: 400px;
	
}
</style>


<div class="row">
<div class="col-xs-12 col-sm-12"> 
	<div class="box">
		
		 <form action="./user_list.php?a=qset&user=<?=$user?>" method="post" class="form-horizontal" role="form">
		 <input type="hidden" name="type" value="update" />
	
			<div class="form-group" >
				<label for="firstname" class="col-sm-2 control-label">密码</label>
				<div class="col-sm-10">
					<input class="form-control" rows="10" name="pass" value="<?=$row['value']?>">
				</div>
			</div>
			
			<div class="form-group" >
				<label for="firstname" class="col-sm-2 control-label">修改状态</label>
				<div class="col-sm-10">
					 <select name="state" class="form-control">
						<option value="boya-Disable-Password">禁用</option>
						<option value="Cleartext-Password">启用</option>
					  </select>
				</div>
			</div>
			<div class="form-group" >
				<label for="firstname" class="col-sm-2 control-label">当天套餐</label>
				<div class="col-sm-10">
					<input type="text" value="<?=$row_1['groupname']?>" class="form-control" disabled>
				</div>
			</div>

			<div class="form-group" >
				<label for="firstname" class="col-sm-2 control-label">修改套餐</label>
				<div class="col-sm-10">
					<select name="enddate">
					<?php
					$user_add_groupname = db('radgroupcheck')->field('DISTINCT(groupname)')->select();
					foreach($user_add_groupname as $user_add_groupnames){
						echo "<option value='{$user_add_groupnames['groupname']}'>{$user_add_groupnames['groupname']}</option>";
					}
					?>
					</select>
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-offset-2 col-sm-10">
					<input type="submit" name="submit" value="修改" class="btn btn-info btn-block"/>
				</div>
			</div>
		 </form>
	</div>
	
	<div class="box" style="margin-top:10px;">
		<div class="main">
			<div id="line">
			</div>
		</div>
	</div>
	
</div>


<div class="col-xs-12 col-sm-12"> 
	
</div>

</div>

        		<script type="text/javascript">
    
    var json = [
	<?php  
		$temp_date = date("Y-m-d 0:0:0",time());
		$now = strtotime($temp_date); 
		for($i=0;$i<=30;$i++){
			$t = $now-((30-$i)*24*60*60);
			$p = date("Y-m-d",$t);
			
			//$res = $DB->get_row("select * from `top` where `username`='".$user."' AND time='".$p."' limit 1");
			$res = db("top")->where(array("username"=>$user,"time"=>$p))->find();
			
			if($res){
				$value = $res['data'] / 1024 / 1024;
				$data[] = '{ "name": "'.date("d",$t).'日", "value": "'.round($value,3).'" }';
			}else{
				$data[] = '{ "name": "'.date("d",$t).'日", "value": "0" }';
			}
			
		}
		echo implode(",",$data);
$qset_passwork = db('radcheck')->where(array('username'=>$user))->select();
$qset_ud = new test($qset_passwork[0]['username'],$qset_passwork[0]['value'],true);
$qset_username_ud = $qset_ud->getllts();
$qset_sy_ud = round($qset_username_ud[1]/1024/1024,2) - round($qset_username_ud[0]/1024/1024,2);
	?>
  
  
  ];
  var data = [
		{"name":"上传流量(MB)","value":"<?php echo round($qset_username_ud[3]/1024/1024,2);?>"},
		{"name":"下载流量(MB)","value":"<?php echo round($qset_username_ud[4]/1024/1024,2);?>"},
		{"name":"剩余流量(MB)","value":"<?php echo $qset_sy_ud;?>"}
  ];
  $(document).ready(function (e) {
        //GetSerialChart();
        MakeChart(data);
    });
  
    //折线图
    AmCharts.ready(function () {
        var chart = new AmCharts.AmSerialChart();
        chart.dataProvider = json;
        chart.categoryField = "name";
        chart.angle = 30;
        chart.depth3D = 20;
        //标题
        chart.addTitle("30天流量趋势", 15);  
        var graph = new AmCharts.AmGraph();
        chart.addGraph(graph);
        graph.valueField = "value";
        //背景颜色透明度
        graph.fillAlphas = 0.3;
        //类型
        graph.type = "line";
        //圆角
        graph.bullet = "round";
        //线颜色
        graph.lineColor = "#8e3e1f";
        //提示信息
        graph.balloonText = "[[name]]: [[value]]";
        var categoryAxis = chart.categoryAxis;
        categoryAxis.autoGridCount = false;
        categoryAxis.gridCount = json.length;
        categoryAxis.gridPosition = "start";
        chart.write("line");
    });
    //饼图
    //根据json数据生成饼状图，并将饼状图显示到div中
    function MakeChart(value) {
        chartData = eval(value);
        //饼状图
        chart = new AmCharts.AmPieChart();
        chart.dataProvider = chartData;
        //标题数据
        chart.titleField = "name";
        //值数据
        chart.valueField = "value";
        //边框线颜色
        chart.outlineColor = "#fff";
        //边框线的透明度
        chart.outlineAlpha = .8;
        //边框线的狂宽度
        chart.outlineThickness = 1;
        chart.depth3D = 20;
        chart.angle = 30;
        chart.write("pie");
    }
</script>
</div>
 <script src="./js/datepicker/bootstrap-datepicker.js"></script>
 <?php } ?>
