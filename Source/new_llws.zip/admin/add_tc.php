<?php
 	include('head.php');
	include('nav.php');
 	if($_GET['act'] == 'update'){
		$update_add_tc = $_GET['id'];
			$db = db('radgroupcheck');
			if(db("radgroupcheck")->where(array('groupname'=>$_POST['name']))->delete()){
			$db = db('radgroupcheck');
				$db->insert(array(
				'groupname'=>$_POST['name'],
				'attribute'=>'Max-Active-Days',
				'op'=>':=',
				'value'=>$_POST['limit']
				));
				$db->insert(array(
				'groupname'=>$_POST['name'],
				'attribute'=>'Max-Global-Traffic',
				'op'=>':=',
				'value'=>$_POST['rate']
				));
				$db->insert(array(
				'groupname'=>$_POST['name'],
				'attribute'=>'Simultaneous-Use',
				'op'=>':=',
				'value'=>$_POST['content']
				));
				tip_success("套餐修改成功",'add_tc.php?act=mod&id='.$_GET['id']);
			}else{
				tip_failed("十分抱歉修改失败",'add_tc.php?act=mod&id='.$_GET['id']);
			}
		
	}elseif($_GET['act'] == 'add'){
		if(is_numeric($_POST['limit']) || is_numeric($_POST['rate']) || is_numeric($_POST['content'])){
			$db = db('radgroupcheck');
			if($db->insert(array(
				'groupname'=>$_POST['name'],
				'attribute'=>'Max-Active-Days',
				'op'=>':=',
				'value'=>$_POST['limit']
			))){
				$db->insert(array(
				'groupname'=>$_POST['name'],
				'attribute'=>'Max-Global-Traffic',
				'op'=>':=',
				'value'=>$_POST['rate']
				));
				$db->insert(array(
				'groupname'=>$_POST['name'],
				'attribute'=>'Simultaneous-Use',
				'op'=>':=',
				'value'=>$_POST['content']
				));
				tip_success("新增消息【".$_POST['name']."】成功！",'add_tc.php');
			}else{
				tip_failed("十分抱歉修改失败",'add_tc.php');
			}
		}else{
			tip_failed("十分抱歉修改失败,请您检查(有效期,流量限额,同时在线人数)是否为数字,请您填写数字后重新提交!)",'add_tc.php');
		}
		
	}else{

		
	$action = '?act=add';
	if($_GET['act'] == 'mod'){
		//$info = db('radgroupcheck')->where(array('id'=>$_GET['id']))->find();
		$add_list_groupname = $_GET['id'];
		$add_gc_ll = db('radgroupcheck')->where("groupname = '$add_list_groupname' and attribute = 'Max-Global-Traffic'")->field('SUM(value)')->select();//流量
		$add_gc_ts = db('radgroupcheck')->where("groupname = '$add_list_groupname' and attribute = 'Max-Active-Days'")->field('SUM(value)')->select();//天数
		$add_gc_zx = db('radgroupcheck')->where("groupname = '$add_list_groupname' and attribute = 'Simultaneous-Use'")->field('SUM(value)')->select();//人数
		$add_gc_zx[0]['SUM(value)'] = $add_gc_zx[0]['SUM(value)'] ? $add_gc_zx[0]['SUM(value)'] : 999;
		$add_gc_ll[0]['SUM(value)'] = $add_gc_ll[0]['SUM(value)'] ? $add_gc_ll[0]['SUM(value)'] : 999*1024;
		
		$action = "?act=update&id=".$_GET['id'];
	}
		
 ?>
<div class="box">
<div class="main">
	<form class="form-horizontal" role="form" method="POST" action="<?php echo $action?>" onsubmit="return checkStr()">
    <div class="form-group">
        <label for="firstname" class="col-sm-2 control-label">套餐名称 <font style="color:red">(为了避免用户错误禁止修改名称)</font></label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="name" placeholder="标题" value="<?php echo $add_list_groupname ?>">
        </div>
    </div>
     <div class="form-group">
        <label for="firstname" class="col-sm-2 control-label">有效期(天) <font style="color:red">*</font></label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="limit" placeholder="30" value="<?php echo $add_gc_ts[0]['SUM(value)'] ?>">
        </div>
    </div>
    <div class="form-group">
        <label for="firstname" class="col-sm-2 control-label">流量限额(M) <font style="color:red">(这里填)</font></label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="rate" placeholder="1024" value="<?php echo $add_gc_ll[0]['SUM(value)'] ?>">
        </div>
    </div>
    <div class="form-group">
        <label for="firstname" class="col-sm-2 control-label">同时在线人数(人) <font style="color:red">*</font></label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="content" placeholder="1" value="<?php echo $add_gc_zx[0]['SUM(value)'] ?>">
        </div>
    </div>
    <!-- <div class="form-group">
        <label for="firstname" class="col-sm-2 control-label">购买连接</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="url" placeholder="http://abc.cn/buy/122" value="<?php echo $info['url'] ?>">
        </div>
    </div>
	
    <div class="form-group" >
        <label for="name" class="col-sm-2 control-label">套餐描述</label>
         <div class="col-sm-10"><textarea class="form-control" rows="10" name="content"><?php echo $info['content'] ?></textarea></div>
    </div>-->
    
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-info btn-block">提交数据</button>
        </div>
    </div>
	</form> 
</div>
</div>
	<script>
	function checkStr(){
		var title = $('[name="limit"]').val();
		var content = $('[name="content"]').val();
		var rate = $('[name="rate"]').val();
		if(title == "" && content ==　""){
			alert("天数与同时在线人数不得为空");
			return false;
		}
	}
	</script>
<?php
	}
	include('footer.php');
	
?>
